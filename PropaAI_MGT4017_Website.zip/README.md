# PropaAI – MGT4017
A mobile-friendly student estate agency website prototype, featuring searchable demonstration listings by location, buying/renting, property type and maximum budget.

## Publish on GitHub Pages
1. Open your GitHub repository `lk09/mgt0417`.
2. Choose **Add file → Upload files** and upload `index.html` from this folder (not the ZIP itself).
3. Commit the change to the `main` branch.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, select **Deploy from a branch**, branch **main**, folder **/(root)**, then **Save**.
6. Wait for GitHub Pages to publish. The expected address is `https://lk09.github.io/mgt0417/` (verify it loads before submitting).

## Evidence
Take screenshots of your GitHub profile, repository file list, and published website. Paste them into the supplied Word document and verify the live URL.

All listings are fictional and the site does not provide real AI services.
